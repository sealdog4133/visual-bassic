﻿Public Class Form1
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Dim test1 As VariantType
        Dim test2 As VariantType

        test1 = txtInput.Text
        test2 = "1234"

        If test1 <> test2 Then
            MsgBox("비밀번호가 틀렸습니다.")
        End If
    End Sub
End Class
