﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblPW = New Label()
        txtInput = New TextBox()
        btnOK = New Button()
        SuspendLayout()
        ' 
        ' lblPW
        ' 
        lblPW.Font = New Font("굴림", 11.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(129))
        lblPW.Location = New Point(233, 43)
        lblPW.Name = "lblPW"
        lblPW.Size = New Size(100, 23)
        lblPW.TabIndex = 0
        lblPW.Text = "패스워드"
        lblPW.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' txtInput
        ' 
        txtInput.Location = New Point(195, 91)
        txtInput.MaxLength = 4
        txtInput.Name = "txtInput"
        txtInput.PasswordChar = "*"c
        txtInput.Size = New Size(168, 23)
        txtInput.TabIndex = 1
        ' 
        ' btnOK
        ' 
        btnOK.Location = New Point(242, 171)
        btnOK.Name = "btnOK"
        btnOK.Size = New Size(75, 23)
        btnOK.TabIndex = 2
        btnOK.Text = "확인"
        btnOK.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(569, 288)
        Controls.Add(btnOK)
        Controls.Add(txtInput)
        Controls.Add(lblPW)
        Name = "Form1"
        Text = "패스워드"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblPW As Label
    Friend WithEvents txtInput As TextBox
    Friend WithEvents btnOK As Button

End Class
