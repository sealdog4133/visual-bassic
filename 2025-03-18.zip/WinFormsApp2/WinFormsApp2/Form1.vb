﻿Public Class Form1
    Private Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        lbloutput.Text = txtid.Text + "님 환영합니다."
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        lbloutput.Text = "다시 입력해주세요."
        txtid.Text = ""
        txtpassword.Text = ""
        txtid.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        End
    End Sub
End Class
