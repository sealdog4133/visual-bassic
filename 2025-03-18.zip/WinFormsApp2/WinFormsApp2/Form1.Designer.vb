﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblid = New Label()
        lblpassword = New Label()
        lbloutput = New Label()
        txtid = New TextBox()
        txtpassword = New TextBox()
        btnExit = New Button()
        btnOk = New Button()
        btnCancel = New Button()
        SuspendLayout()
        ' 
        ' lblid
        ' 
        lblid.AutoSize = True
        lblid.Location = New Point(80, 66)
        lblid.Name = "lblid"
        lblid.Size = New Size(43, 15)
        lblid.TabIndex = 0
        lblid.Text = "아이디"
        ' 
        ' lblpassword
        ' 
        lblpassword.AutoSize = True
        lblpassword.Location = New Point(80, 129)
        lblpassword.Name = "lblpassword"
        lblpassword.Size = New Size(55, 15)
        lblpassword.TabIndex = 1
        lblpassword.Text = "비밀번호"
        ' 
        ' lbloutput
        ' 
        lbloutput.AutoSize = True
        lbloutput.BorderStyle = BorderStyle.FixedSingle
        lbloutput.Location = New Point(80, 194)
        lbloutput.Name = "lbloutput"
        lbloutput.Size = New Size(2, 17)
        lbloutput.TabIndex = 2
        ' 
        ' txtid
        ' 
        txtid.Location = New Point(233, 63)
        txtid.Name = "txtid"
        txtid.Size = New Size(127, 23)
        txtid.TabIndex = 3
        ' 
        ' txtpassword
        ' 
        txtpassword.Location = New Point(233, 126)
        txtpassword.Name = "txtpassword"
        txtpassword.PasswordChar = "*"c
        txtpassword.Size = New Size(127, 23)
        txtpassword.TabIndex = 4
        ' 
        ' btnExit
        ' 
        btnExit.Location = New Point(371, 262)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(75, 23)
        btnExit.TabIndex = 5
        btnExit.Text = "종료"
        btnExit.UseVisualStyleBackColor = True
        ' 
        ' btnOk
        ' 
        btnOk.Location = New Point(80, 262)
        btnOk.Name = "btnOk"
        btnOk.Size = New Size(75, 23)
        btnOk.TabIndex = 6
        btnOk.Text = "확인"
        btnOk.UseVisualStyleBackColor = True
        ' 
        ' btnCancel
        ' 
        btnCancel.Location = New Point(233, 262)
        btnCancel.Name = "btnCancel"
        btnCancel.Size = New Size(75, 23)
        btnCancel.TabIndex = 7
        btnCancel.Text = "취소"
        btnCancel.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(573, 339)
        Controls.Add(btnCancel)
        Controls.Add(btnOk)
        Controls.Add(btnExit)
        Controls.Add(txtpassword)
        Controls.Add(txtid)
        Controls.Add(lbloutput)
        Controls.Add(lblpassword)
        Controls.Add(lblid)
        Name = "Form1"
        Text = "회원정보"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblid As Label
    Friend WithEvents lblpassword As Label
    Friend WithEvents lbloutput As Label
    Friend WithEvents txtid As TextBox
    Friend WithEvents txtpassword As TextBox
    Friend WithEvents btnExit As Button
    Friend WithEvents btnOk As Button
    Friend WithEvents btnCancel As Button

End Class
