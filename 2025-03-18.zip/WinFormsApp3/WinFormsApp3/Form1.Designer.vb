﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        lalMessage = New Label()
        btnHello = New Button()
        btnVB = New Button()
        btnProgramming = New Button()
        btnImg = New Button()
        SuspendLayout()
        ' 
        ' lalMessage
        ' 
        lalMessage.AutoSize = True
        lalMessage.Location = New Point(134, 69)
        lalMessage.Name = "lalMessage"
        lalMessage.Size = New Size(0, 15)
        lalMessage.TabIndex = 0
        lalMessage.TextAlign = ContentAlignment.TopCenter
        ' 
        ' btnHello
        ' 
        btnHello.Location = New Point(134, 138)
        btnHello.Name = "btnHello"
        btnHello.Size = New Size(190, 23)
        btnHello.TabIndex = 1
        btnHello.Text = "안녕하세요"
        btnHello.UseVisualStyleBackColor = True
        ' 
        ' btnVB
        ' 
        btnVB.Location = New Point(134, 181)
        btnVB.Name = "btnVB"
        btnVB.Size = New Size(190, 23)
        btnVB.TabIndex = 1
        btnVB.Text = "비쥬얼 베이직"
        btnVB.UseVisualStyleBackColor = True
        ' 
        ' btnProgramming
        ' 
        btnProgramming.Location = New Point(134, 225)
        btnProgramming.Name = "btnProgramming"
        btnProgramming.Size = New Size(190, 23)
        btnProgramming.TabIndex = 1
        btnProgramming.Text = "프로그래밍"
        btnProgramming.UseVisualStyleBackColor = True
        ' 
        ' btnImg
        ' 
        btnImg.Image = CType(resources.GetObject("btnImg.Image"), Image)
        btnImg.Location = New Point(134, 269)
        btnImg.Name = "btnImg"
        btnImg.Size = New Size(190, 23)
        btnImg.TabIndex = 1
        btnImg.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(517, 390)
        Controls.Add(btnImg)
        Controls.Add(btnProgramming)
        Controls.Add(btnVB)
        Controls.Add(btnHello)
        Controls.Add(lalMessage)
        Name = "Form1"
        Text = "Button 컨트롤"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lalMessage As Label
    Friend WithEvents btnHello As Button
    Friend WithEvents btnVB As Button
    Friend WithEvents btnProgramming As Button
    Friend WithEvents btnImg As Button

End Class
