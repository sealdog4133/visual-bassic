﻿Public Class Form1
    Private Sub btnHello_Click(sender As Object, e As EventArgs) Handles btnHello.Click
        lalMessage.Text = "안녕하세요"
    End Sub

    Private Sub btnVB_Click(sender As Object, e As EventArgs) Handles btnVB.Click
        lalMessage.Text = "비쥬얼 베이직"
    End Sub

    Private Sub btnProgramming_Click(sender As Object, e As EventArgs) Handles btnProgramming.Click
        lalMessage.Text = "프로그래밍"
    End Sub

    Private Sub btnImg_Click(sender As Object, e As EventArgs) Handles btnImg.Click
        End
    End Sub
End Class
