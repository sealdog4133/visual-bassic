﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btnOutput = New Button()
        lblMessage = New Label()
        btnExit = New Button()
        txtOutput = New TextBox()
        txtInput = New TextBox()
        SuspendLayout()
        ' 
        ' btnOutput
        ' 
        btnOutput.Location = New Point(404, 151)
        btnOutput.Name = "btnOutput"
        btnOutput.Size = New Size(123, 53)
        btnOutput.TabIndex = 0
        btnOutput.Text = "출력"
        btnOutput.UseVisualStyleBackColor = True
        ' 
        ' lblMessage
        ' 
        lblMessage.AutoSize = True
        lblMessage.Location = New Point(122, 98)
        lblMessage.Name = "lblMessage"
        lblMessage.Size = New Size(43, 15)
        lblMessage.TabIndex = 1
        lblMessage.Text = "입력값"
        ' 
        ' btnExit
        ' 
        btnExit.Location = New Point(101, 272)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(87, 23)
        btnExit.TabIndex = 2
        btnExit.Text = "종료"
        btnExit.UseVisualStyleBackColor = True
        ' 
        ' txtOutput
        ' 
        txtOutput.Location = New Point(371, 272)
        txtOutput.Name = "txtOutput"
        txtOutput.Size = New Size(276, 23)
        txtOutput.TabIndex = 3
        ' 
        ' txtInput
        ' 
        txtInput.Location = New Point(371, 90)
        txtInput.Name = "txtInput"
        txtInput.Size = New Size(276, 23)
        txtInput.TabIndex = 4
        ' 
        ' frmMain
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtInput)
        Controls.Add(txtOutput)
        Controls.Add(btnExit)
        Controls.Add(lblMessage)
        Controls.Add(btnOutput)
        Name = "frmMain"
        Text = "TextBox 컨트롤"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnOutput As Button
    Friend WithEvents lblMessage As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents txtOutput As TextBox
    Friend WithEvents txtInput As TextBox

End Class
