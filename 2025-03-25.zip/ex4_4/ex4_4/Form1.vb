﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ComboBox1.Text = "USD" Then
            TextBox2.Text = CLng(TextBox1.Text * 1124)
        End If
        If ComboBox1.Text = "EUR" Then
            TextBox2.Text = CLng(TextBox1.Text * 1260)
        End If
        If ComboBox1.Text = "CNY" Then
            TextBox2.Text = CLng(TextBox1.Text * 165)
        End If
        If ComboBox1.Text = "JPY" Then
            TextBox2.Text = CLng(TextBox1.Text * 10)
        End If
        If ComboBox1.Text = "HKD" Then
            TextBox2.Text = CLng(TextBox1.Text * 144)
        End If
    End Sub
End Class
