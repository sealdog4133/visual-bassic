﻿Public Class Form1
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        TextBox1.ForeColor = Color.Red
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        TextBox1.ForeColor = Color.Blue
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        TextBox1.ForeColor = Color.green
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        TextBox1.ForeColor = Color.yellow
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            TextBox1.Font = New Font(TextBox1.Font.Name, 15, FontStyle.Bold, GraphicsUnit.World)
        Else
            CheckBox1.Checked = False
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            TextBox1.Font = New Font(TextBox1.Font.Name, 15, FontStyle.Underline, GraphicsUnit.World)
        Else
            CheckBox2.Checked = False
        End If
    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            TextBox1.Font = New Font(TextBox1.Font.Name, 15, FontStyle.Strikeout, GraphicsUnit.World)
        Else
            CheckBox3.Checked = false
        End If
    End Sub

    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox4.CheckedChanged
        If CheckBox4.Checked = True Then
            TextBox1.Font = New Font(TextBox1.Font.Name, 15, FontStyle.Italic, GraphicsUnit.World)
        Else
            CheckBox4.Checked = false
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        RadioButton1.Checked = 0
        RadioButton2.Checked = 0
        RadioButton3.Checked = 0
        RadioButton4.Checked = 0

        CheckBox1.Checked = 0
        CheckBox2.Checked = 0
        CheckBox3.Checked = 0
        CheckBox4.Checked = 0

        TextBox1.ForeColor = Color.Black
        TextBox1.Font = DefaultFont
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End
    End Sub
End Class
