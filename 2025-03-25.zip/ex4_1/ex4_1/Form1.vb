﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If RadioButton1.Checked = True Then
            Label1.Text = "안녕하세요"
        ElseIf RadioButton2.Checked = True Then
            Label1.Text = "비주얼 베이직"
        ElseIf RadioButton3.Checked = True Then
            Label1.Text = "프로그래밍"
        End If
    End Sub
End Class
