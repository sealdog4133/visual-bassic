﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim reslut As String

        If TextBox2.Text >= 70 Then
            reslut = "합격입니다."
        Else
            reslut = "불합격입니다."
        End If
        MsgBox(TextBox1.Text & "님의 점수는" & TextBox2.Text & "점 입니다." & reslut)
    End Sub
End Class
