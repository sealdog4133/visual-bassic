﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a As Integer

        a = Val(TextBox2.Text)

        If a >= 90 Then
            TextBox1.Text = "A"
        ElseIf a >= 80 Then
            TextBox1.Text = "B"
        ElseIf a >= 70 Then
            TextBox1.Text = "C"
        ElseIf a >= 60 Then
            TextBox1.Text = "D"
        ElseIf a >= 50 Then
            TextBox1.Text = "F"
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox1.Focus()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub
End Class
