﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim C언어, 운영체제, 총점, 반올림평균 As Integer
        Dim 평균 As Double
        Dim 학점 As String

        C언어 = Val(TextBox1.Text)
        운영체제 = Val(TextBox2.Text)

        총점 = C언어 + 운영체제
        TextBox3.Text = 총점

        평균 = 총점 / 2
        TextBox4.Text = 평균

        반올림평균 = Int(평균 + 0.5)
        TextBox6.Text = 반올림평균

        Select Case 반올림평균
            Case 90 To 100
                학점 = "A"
            Case 80 To 89
                학점 = "B"
            Case 70 To 79
                학점 = "C"
            Case 60 To 69
                학점 = "D"
            Case Else
                학점 = "F"
        End Select
        TextBox5.Text = 학점
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox1.Focus()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub
End Class
