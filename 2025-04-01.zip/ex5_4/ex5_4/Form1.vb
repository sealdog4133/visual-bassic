﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Last_day As Integer
        Last_day = Val(TextBox1.Text)
        Select Case Last_day
            Case 2
                TextBox2.Text = 28
            Case 1, 3, 5, 7, 8, 10, 12
                TextBox2.Text = 31
            Case 4, 6, 9, 11
                TextBox2.Text = 30
        End Select
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox1.Focus()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub
End Class
