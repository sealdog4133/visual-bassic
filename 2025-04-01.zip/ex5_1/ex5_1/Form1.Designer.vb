﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        TextBox1 = New TextBox()
        CheckBox1 = New CheckBox()
        GroupBox1 = New GroupBox()
        Button1 = New Button()
        CheckBox2 = New CheckBox()
        CheckBox3 = New CheckBox()
        SuspendLayout()
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(278, 72)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(205, 23)
        TextBox1.TabIndex = 0
        ' 
        ' CheckBox1
        ' 
        CheckBox1.AutoSize = True
        CheckBox1.Location = New Point(291, 160)
        CheckBox1.Name = "CheckBox1"
        CheckBox1.Size = New Size(89, 19)
        CheckBox1.TabIndex = 1
        CheckBox1.Text = "환영합니다!"
        CheckBox1.UseVisualStyleBackColor = True
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Location = New Point(262, 127)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(152, 173)
        GroupBox1.TabIndex = 2
        GroupBox1.TabStop = False
        GroupBox1.Text = "선택"
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(436, 200)
        Button1.Name = "Button1"
        Button1.Size = New Size(75, 23)
        Button1.TabIndex = 3
        Button1.Text = "출력"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' CheckBox2
        ' 
        CheckBox2.AutoSize = True
        CheckBox2.Location = New Point(291, 203)
        CheckBox2.Name = "CheckBox2"
        CheckBox2.Size = New Size(102, 19)
        CheckBox2.TabIndex = 4
        CheckBox2.Text = "비주얼 베이직"
        CheckBox2.UseVisualStyleBackColor = True
        ' 
        ' CheckBox3
        ' 
        CheckBox3.AutoSize = True
        CheckBox3.Location = New Point(291, 246)
        CheckBox3.Name = "CheckBox3"
        CheckBox3.Size = New Size(86, 19)
        CheckBox3.TabIndex = 5
        CheckBox3.Text = "프로그래밍"
        CheckBox3.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(CheckBox3)
        Controls.Add(CheckBox2)
        Controls.Add(Button1)
        Controls.Add(CheckBox1)
        Controls.Add(TextBox1)
        Controls.Add(GroupBox1)
        Name = "Form1"
        Text = "단순IF문"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Button1 As Button
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox3 As CheckBox

End Class
