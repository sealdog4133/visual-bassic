﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim test As String

        If CheckBox1.Checked = True Then
            test = test + "환영합니다"
        End If

        If CheckBox2.Checked = True Then
            test = test + "비주얼 베이직"
        End If

        If CheckBox3.Checked = True Then
            test = test + "프로그래밍"
        End If

        If test = "" Then
            MsgBox("항목을 입력해주세요")
        End If

        TextBox1.Text = test
    End Sub
End Class
